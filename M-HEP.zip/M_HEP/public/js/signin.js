const slider = document.getElementById("slider")
const login = document.getElementById("login")
const register = document.getElementById("register")

function slide() {
    slider.classList.toggle("slider_move")
    login.classList.toggle("active")
    register.classList.toggle("active")
}