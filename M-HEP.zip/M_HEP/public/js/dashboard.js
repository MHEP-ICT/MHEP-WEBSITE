function menu(index, id) {

    const links = document.getElementsByTagName("li")
    const active_link = document.getElementsByClassName("active")
    const display = document.getElementById(id)
    const display_active = document.getElementsByClassName("current")

    if (active_link.length > 0) {
        active_link[0].classList.remove("active")
    }

    links[index].classList.add('active')

    if (display_active.length > 0) {
        display_active[0].classList.remove("current")
    }

    display.classList.add('current')
}